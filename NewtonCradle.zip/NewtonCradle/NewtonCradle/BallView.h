//
//  BallView.h
//  NewtonCradle
//
//  Created by wang xinkai on 15/9/6.
//  Copyright © 2015年 wxk. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface BallView : UIView

//是否响应触摸
@property (nonatomic,assign) BOOL isTouchEnabled;
//设置为球形
@property (nonatomic,assign) BOOL isBall;
@end
