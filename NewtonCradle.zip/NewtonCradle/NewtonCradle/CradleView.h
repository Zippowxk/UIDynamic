//
//  CradleView.h
//  NewtonCradle
//
//  Created by wang xinkai on 15/9/6.
//  Copyright © 2015年 wxk. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BallView.h"
@interface CradleView : UIView<UICollisionBehaviorDelegate>
{
    //items
    NSMutableArray *_balls;
    //animator
    UIDynamicAnimator *_animator;
    
    //    anchors
    CGPoint _anchors[100];
    // centers
    CGPoint _centers[100];
    //    设置线的长度
    CGFloat _attachmentLength;
    CGFloat radius;
}
@end
