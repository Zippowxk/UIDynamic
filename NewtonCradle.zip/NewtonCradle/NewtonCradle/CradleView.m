//
//  CradleView.m
//  NewtonCradle
//
//  Created by wang xinkai on 15/9/6.
//  Copyright © 2015年 wxk. All rights reserved.
//

#import "CradleView.h"

@implementation CradleView

-(id)initWithFrame:(CGRect)frame{
    
    if (self = [super initWithFrame:frame]) {
        
        
        [self loadSettings];
        _balls = [[NSMutableArray alloc] init];
        self.backgroundColor = [UIColor lightGrayColor];
        [self createKits];
        _animator = [[UIDynamicAnimator alloc] initWithReferenceView:self];
        [self performSelector:@selector(addBehavior) withObject:nil afterDelay:0];
        
    }
    return self;
}

#pragma mark - 默认设置

-(void)loadSettings{
    
    //    设置线的长度
    _attachmentLength = 200;
    radius = 20;
    
}

#pragma mark - Xib文件进入方法

-(void)awakeFromNib{
    [self loadSettings];
    _balls = [[NSMutableArray alloc] init];
    self.backgroundColor = [UIColor lightGrayColor];
    [self createKits];
    _animator = [[UIDynamicAnimator alloc] initWithReferenceView:self];
    [self performSelector:@selector(addBehavior) withObject:nil afterDelay:0];


}


#pragma mark - 重新布局方法
-(void)layoutSubviews{
    [super layoutSubviews];
    
    [self createKits];
}
#pragma mark - 创建控件

-(void)createKits{
    

    
//   中心
    CGPoint center = self.center;
//    半径
    
    CGPoint centers[] = {
        CGPointMake(center.x-4*radius, center.y),
        CGPointMake(center.x-2*radius, center.y),
        CGPointMake(center.x, center.y),
        CGPointMake(center.x+2*radius,center.y),
        CGPointMake(center.x+4*radius, center.y),
    };
    int count = sizeof(centers)/sizeof(CGPoint);

    
//    更新两个数组
    for (int i = 0; i<count; i++) {
        _centers[i] = centers[i];
        _anchors[i] = centers[i];
        _anchors[i].y -= _attachmentLength;
        
    }
    
//    重新布局代码
    if (_balls.count) {
        
        int i = 0;
        for (UIView *view in _balls) {
            
            view.center = centers[i];
            i++;
            
        }
        [self setNeedsDisplay];
        return;
    }
 
    //    创建Balls

    for (int i = 0; i<count; i++) {
        
        BallView *ball = [[BallView alloc] initWithFrame:CGRectMake(0, 0, radius*2-1, radius*2-1)];
        ball.isBall = YES;
        ball.center = centers[i];

        //添加KVO
        [ball addObserver:self forKeyPath:@"center" options:NSKeyValueObservingOptionNew context:nil];
        
        [self addSubview:ball];
        [_balls addObject:ball];

    }
    [self setNeedsDisplay];
    
}

#pragma mark - 添加行为

//添加行为描述
-(void)addBehavior{
    
    //    item 的行为描述
    UIDynamicItemBehavior *itemBehavior = [[UIDynamicItemBehavior alloc] initWithItems:_balls];
//    //    设置密度
    itemBehavior.density = 1;
    //弹性
    itemBehavior.elasticity = 1;
    
    itemBehavior.allowsRotation = NO;
    //阻尼
    itemBehavior.resistance = 1;
    [_animator addBehavior:itemBehavior];
    
    
    //    重力行为
    
    UIGravityBehavior *behavior  = [[UIGravityBehavior alloc] initWithItems:_balls];
    
    behavior.magnitude = 10;
    [_animator addBehavior:behavior];

    
    
    //连接行为
    
    for (int i = 0; i<_balls.count; i++) {
        UIAttachmentBehavior *attachment = [[UIAttachmentBehavior alloc] initWithItem:_balls[i] offsetFromCenter:UIOffsetMake(0, -radius) attachedToAnchor:_anchors[i]];
        
//        //    连接长度
//        attachment.length = _attachmentLength;
//        //    衰减
        attachment.damping = .1;
//        //    频率
//        attachment.frequency = 5;
        
        
        [_animator addBehavior:attachment];

    }
    
 
    //碰撞行为
    
    
    UICollisionBehavior *collision = [[UICollisionBehavior alloc] initWithItems:_balls];
    
    collision.collisionMode = UICollisionBehaviorModeItems;
    collision.collisionDelegate = self;
    //设置边缘碰撞
//    collision.translatesReferenceBoundsIntoBoundary = YES;
    
    [_animator addBehavior:collision];

    
    
    
//    添加手势
    
    UISwipeGestureRecognizer *ges = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swipeAct:)];
    ges.direction = UISwipeGestureRecognizerDirectionLeft;
    [self addGestureRecognizer:ges];
    
    
}

#pragma mark - 手势力
-(void)swipeAct:(UISwipeGestureRecognizer*)ges{
    
    UIPushBehavior *push = [[UIPushBehavior alloc] initWithItems:@[_balls[0]] mode:UIPushBehaviorModeInstantaneous];
    push.pushDirection = CGVectorMake(-1, 0);
    push.magnitude = 2;
    [_animator addBehavior:push];
    
    
    
}


#pragma mark - 绘制

//重绘
- (void)drawRect:(CGRect)rect {

    
    long count = _balls.count;

    
    CGContextRef context = UIGraphicsGetCurrentContext();

//    锚点
    
    for (int i = 0; i<count; i++) {
        CGContextAddArc(context, _anchors[i].x, _anchors[i].y , 5, 0, M_PI*2, true);
        CGContextFillPath(context);
    }
    
    
    
    
    
//    线
    
    for (int i = 0; i<count; i++) {

        CGPoint center = [_balls[i] center];
        
        CGContextMoveToPoint(context, center.x,center.y);
        CGContextAddLineToPoint(context, _anchors[i].x, _anchors[i].y);
    }
    

    
    //虚线
    //    CGFloat f[1] = {10};
    //    CGContextSetLineDash(context, 10, f, 1);
    
    
    CGContextStrokePath(context);

    
}

#pragma mark - KVO
-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context{
    
    [self setNeedsDisplay];
}

-(void)dealloc
{
    for (BallView *ball in _balls) {
        [ball removeObserver:self forKeyPath:@"center"];
    }
}

@end
