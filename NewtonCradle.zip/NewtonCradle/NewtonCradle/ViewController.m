//
//  ViewController.m
//  NewtonCradle
//
//  Created by wang xinkai on 15/9/6.
//  Copyright © 2015年 wxk. All rights reserved.
//

#import "ViewController.h"
#import "CradleView.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    UIView *v = [[CradleView alloc] initWithFrame:self.view.bounds];
    [self.view addSubview:v];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
